$(document).ready(function(){
    var $gallery = $('.gallery');

    $gallery.vitGallery({
        debag: true
    })
})
